public class No {
    public int valor;
    public No proximo;
    public No anterior;

    public No(int valor){
        this.valor = valor;
        this.proximo = null;
        this.anterior = null;
    }
}
