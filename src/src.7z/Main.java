public class Main {
    public static void main(String[] args) {
        Lista lista = new Lista();
        lista.adicionarInicio(3);
        lista.adicionarInicio(4);
        lista.printarLista();
        System.out.println();
        lista.adicionarFinal(1);
        lista.printarLista();

    }
}
